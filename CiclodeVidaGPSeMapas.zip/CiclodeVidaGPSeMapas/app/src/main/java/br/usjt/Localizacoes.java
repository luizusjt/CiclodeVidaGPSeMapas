package br.usjt;

import android.location.Location;

public class Localizacoes {
    private Location latitude;
    private Location longitude;


        public Location getLatitude(){
            return latitude;
        }
        public void setLatitude(Location latitude){
            this.latitude = latitude;
        }
        public Location getLongitude(){
            return longitude;
        }
        public void setLongitude(Location longitude){
            this.longitude = longitude;
        }
    }

